Railgun Arena for Q3A by Arcan
=============================================================================
Date                    : 1/03/13
Filename                : q3RgdL.pk3
Author                  : Arcan
=============================================================================
- Play Information -
Gametype(s)		: Tourney; Free-for-all; Team Deathmatch
Players                 : 12-12
Bots                    : Yes
Weapons                 : All weapons
Powerups		: All powerups
To play this map	: Put the q3RgdL.pk3 file into your baseq3 directory
============================================================================
- Construction -
Editor(s) used          : GtkRadiant 1.5
Build Time              : 1 hour